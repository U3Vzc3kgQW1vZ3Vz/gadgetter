package gadgets.collection.markers;

public enum Comparison {
    EQUAL,
    NO_EQUAL_TO,
    SMALLER,
    BIGGER,
    SMALLER_OR_EQUAL,
    BIGGER_OR_EQUAL,
    HAS,
    NO
}
