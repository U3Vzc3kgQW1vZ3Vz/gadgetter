package markers;

public enum RelationShip {
    NONE,
    EQUAL,
    SUB,
    SUPER,
    HAS_SAME_SUPER_AND_SUB,
    HAS_SAME_SUPER,
    HAS_SAME_SUB
}
