package gadgets.collection.markers;

public enum ProtocolType {
    JDK,
    HESSIAN,
    JSON
}
