package util.StaticAnalyzeUtils;

import java.util.Arrays;
import java.util.List;

public class JavaFeatures {
    public static List<String> baseClasses = Arrays.asList("java.lang.String", "int");
}
