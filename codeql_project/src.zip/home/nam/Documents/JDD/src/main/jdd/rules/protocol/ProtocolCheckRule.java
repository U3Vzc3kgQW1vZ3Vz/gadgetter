package rules.protocol;

public interface ProtocolCheckRule {
}
