package cfg;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Path {
    public List<Node> nodes=new ArrayList<>();
}
