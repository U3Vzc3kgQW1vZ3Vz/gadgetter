package markers;

public enum SinkType {
    JNDI,
    LOAD_CLASS,
    INVOKE,
    EXEC,
    FILE,
    SECOND_DES,
    CUSTOM_MyFace,
    CUSTOM_Bsh,
    CUSTOM_Clojure,
    CUSTOM_Groovy,
    CUSTOM
}
