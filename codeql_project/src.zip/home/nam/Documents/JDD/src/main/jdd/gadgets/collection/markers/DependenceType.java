package gadgets.collection.markers;

public enum DependenceType {
    CLASS_NAME,
    CLASS_METHOD,
    METHOD_NAME,
    ARRAY_SIZE,
    ARRAY_ELEMENT,
    ASSIGNED
}
