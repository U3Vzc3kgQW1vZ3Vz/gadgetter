package gadgets.collection.iocd.unit;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ParameterRecord{

    public int pos;
    public String paramName;
    public String paramType;
}
